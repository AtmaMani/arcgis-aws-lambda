from arcgis.widgets._mapview._mapview import MapView
