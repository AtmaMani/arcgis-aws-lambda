"""
StoryMap Implementation
"""
from .storymap import JournalStoryMap

__all__ = ['JournalStoryMap']